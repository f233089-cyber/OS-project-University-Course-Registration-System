/*
 * ============================================================
 * University Course Registration System
 * CL-2006 – Operating Systems Lab | Final Project
 * ============================================================
 * Group Members:
 *   Muhammad Ahmad  (23F-3089)
 *
 * Description:
 *   Simulates a concurrent university course registration system
 *   using POSIX threads (pthreads) in C. Students are modelled as
 *   concurrent threads that compete for limited course seats.
 *
 * OS Concepts Demonstrated:
 *   - POSIX Threads (pthread_create / pthread_join)
 *   - Mutex Locks (per-course and global)
 *   - POSIX Semaphores (concurrency throttle)
 *   - Condition Variables (priority gate)
 *   - Barriers (synchronised thread start)
 *   - Critical Section Problem & Solution
 *   - Deadlock Prevention (single resource acquisition)
 *   - Starvation Avoidance (aging mechanism)
 *
 * Compile:  gcc -Wall -Wextra -o registration registration.c -lpthread
 * Run:      ./registration                   (default: 60 students)
 *           ./registration --students 100    (custom student count)
 *           ./registration --stress          (stress test: 200 students)
 * ============================================================
 */

#define _GNU_SOURCE   /* required for pthread_barrier_t on some systems */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>
#include <stdarg.h>
#include <errno.h>

/* ─────────────────────────────────────────────
 * Compile-time Configuration
 * ───────────────────────────────────────────── */
#define MAX_COURSES          10
#define MAX_STUDENTS         200
#define MAX_COURSES_PER_STD  3
#define MAX_LOG_ENTRIES      2000
#define LOG_FILE             "registration_log.txt"

/* Priority levels */
#define PRIORITY_HIGH  1   /* final-year / graduating student */
#define PRIORITY_LOW   0   /* regular student                 */

/* Aging: after this many waits, a low-priority student bypasses
 * the priority gate to prevent starvation. */
#define AGING_THRESHOLD  3

/* Maximum number of registration operations happening at once.
 * Controlled by a POSIX semaphore (demonstrates sem_wait/sem_post). */
#define MAX_CONCURRENT_REGISTRATIONS 5

/* ─────────────────────────────────────────────
 * Module 1 – Data Structures
 * ───────────────────────────────────────────── */

/*
 * Course – represents a single course offered by the university.
 * Fields:
 *   id             : unique numeric identifier (e.g. 101)
 *   name           : human-readable course name
 *   total_seats    : initial seat capacity
 *   available      : remaining seats (shared mutable state)
 *   lock           : per-course mutex protecting seat data
 *   enrolled_ids   : array of student IDs currently enrolled
 *   enrolled_count : number of students successfully enrolled
 */
typedef struct {
    int             id;
    char            name[48];
    int             total_seats;
    int             available;
    pthread_mutex_t lock;
    int             enrolled_ids[MAX_STUDENTS];
    int             enrolled_count;
} Course;

/*
 * Student – represents a single student thread.
 * Fields:
 *   id           : unique student identifier (S1001 … S1200)
 *   priority     : PRIORITY_HIGH or PRIORITY_LOW
 *   course_ids   : array of course IDs the student wants
 *   num_requests : how many courses the student will attempt
 *   age          : aging counter for starvation prevention
 */
typedef struct {
    int id;
    int priority;
    int course_ids[MAX_COURSES_PER_STD];
    int num_requests;
    int age;
} Student;

/*
 * ThreadArg – passed to each student thread as its argument;
 * also collects per-thread registration results.
 */
typedef struct {
    Student *student;
    int      success_count;
    int      fail_count;
} ThreadArg;

/* ─────────────────────────────────────────────
 * Global Shared State
 * ───────────────────────────────────────────── */
static Course  courses[MAX_COURSES];
static int     num_courses  = 0;       /* actual courses in use */

static Student students[MAX_STUDENTS];
static int     num_students = 0;       /* actual students in use */

/* Global statistics – protected by stats_lock */
static int             total_success = 0;
static int             total_fail    = 0;
static pthread_mutex_t stats_lock    = PTHREAD_MUTEX_INITIALIZER;

/* Log file handle – protected by log_lock */
static FILE           *log_fp   = NULL;
static pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;

/* Barrier: makes all threads start at approximately the same time */
static pthread_barrier_t start_barrier;

/*
 * Module 3 – POSIX Semaphore
 * Limits how many threads can be inside the registration logic
 * simultaneously. Demonstrates sem_wait / sem_post.
 */
static sem_t registration_semaphore;

/*
 * Module 4 – Priority Gate
 * Uses a mutex + condition variable so that high-priority students
 * get preference. Low-priority students wait while any high-priority
 * students are actively registering, unless their aging counter
 * reaches the threshold (starvation prevention).
 */
static pthread_mutex_t priority_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  priority_cond  = PTHREAD_COND_INITIALIZER;
static int             high_priority_active = 0;

/* Program start time – used for elapsed-time display */
static struct timespec program_start_time;

/* ─────────────────────────────────────────────
 * Module 6 – Logging helpers
 * ───────────────────────────────────────────── */

/*
 * get_timestamp – fills buf with current wall-clock time formatted as
 * HH:MM:SS.mmm (hours, minutes, seconds, milliseconds).
 * Parameters:
 *   buf  : destination string buffer
 *   size : size of buf in bytes
 */
static void get_timestamp(char *buf, size_t size)
{
    struct timespec ts;
    struct tm       tm_info;
    clock_gettime(CLOCK_REALTIME, &ts);
    localtime_r(&ts.tv_sec, &tm_info);
    int ms = (int)(ts.tv_nsec / 1000000);
    snprintf(buf, size, "%02d:%02d:%02d.%03d",
             tm_info.tm_hour, tm_info.tm_min, tm_info.tm_sec, ms);
}

/*
 * get_elapsed_ms – returns milliseconds elapsed since program start.
 * Used for relative timestamping in log output.
 */
static double get_elapsed_ms(void)
{
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    double elapsed = (now.tv_sec  - program_start_time.tv_sec)  * 1000.0
                   + (now.tv_nsec - program_start_time.tv_nsec) / 1.0e6;
    return elapsed;
}

/*
 * log_event – thread-safe logging to both stdout and the log file.
 * Prepends a timestamp to every message.
 * Parameters:
 *   fmt : printf-style format string
 *   ... : variadic arguments
 */
static void log_event(const char *fmt, ...)
{
    char    ts[32];
    char    msg[512];
    va_list args;

    get_timestamp(ts, sizeof(ts));
    va_start(args, fmt);
    vsnprintf(msg, sizeof(msg), fmt, args);
    va_end(args);

    pthread_mutex_lock(&log_lock);
    printf("[%s] %s\n", ts, msg);
    if (log_fp)
        fprintf(log_fp, "[%s] %s\n", ts, msg);
    pthread_mutex_unlock(&log_lock);
}

/* ─────────────────────────────────────────────
 * Module 1 – Initialisation helpers
 * ───────────────────────────────────────────── */

/*
 * init_courses – statically initialises courses with predefined names
 * and seat capacities, and sets up their per-course mutexes.
 */
static void init_courses(void)
{
    struct { int id; const char *name; int seats; } data[] = {
        {101, "CS101-Intro to CS",          5},
        {102, "CS102-Data Structures",      4},
        {103, "CS103-Algorithms",           6},
        {104, "CS104-Operating Systems",    3},
        {105, "CS105-Computer Networks",    5},
        {106, "CS106-Database Systems",     4},
        {107, "CS107-Software Engineering", 7},
        {108, "CS108-AI Fundamentals",      3},
    };
    num_courses = 8;

    for (int i = 0; i < num_courses; i++) {
        courses[i].id              = data[i].id;
        strncpy(courses[i].name, data[i].name, sizeof(courses[i].name) - 1);
        courses[i].name[sizeof(courses[i].name) - 1] = '\0';
        courses[i].total_seats     = data[i].seats;
        courses[i].available       = data[i].seats;
        courses[i].enrolled_count  = 0;
        pthread_mutex_init(&courses[i].lock, NULL);
    }
}

/*
 * init_students – creates the requested number of student records.
 * Every 3rd student is marked high-priority (final-year).
 * Each student randomly selects 1–3 distinct courses to register for.
 * Parameters:
 *   count              : total number of students to create
 *   high_priority_pct  : percentage of students that are high-priority
 */
static void init_students(int count, int high_priority_pct)
{
    if (count > MAX_STUDENTS) count = MAX_STUDENTS;
    num_students = count;

    srand((unsigned)time(NULL));

    int high_count = (count * high_priority_pct) / 100;
    if (high_count < 3) high_count = 3;  /* at least 3 as per spec */

    for (int i = 0; i < num_students; i++) {
        students[i].id       = 1001 + i;
        students[i].priority = (i < high_count) ? PRIORITY_HIGH : PRIORITY_LOW;
        students[i].age      = 0;

        /* Pick 1–3 distinct random course indices */
        students[i].num_requests = (rand() % MAX_COURSES_PER_STD) + 1;
        int chosen[MAX_COURSES_PER_STD];
        memset(chosen, -1, sizeof(chosen));

        for (int r = 0; r < students[i].num_requests; r++) {
            int idx, duplicate;
            do {
                duplicate = 0;
                idx = rand() % num_courses;
                for (int k = 0; k < r; k++)
                    if (chosen[k] == idx) { duplicate = 1; break; }
            } while (duplicate);
            chosen[r]                  = idx;
            students[i].course_ids[r]  = courses[idx].id;
        }
    }
}

/* ─────────────────────────────────────────────
 * Module 3 – Synchronisation (Critical Section)
 * ───────────────────────────────────────────── */

/*
 * find_course_index – returns the array index of the course with the
 * given id, or -1 if not found.
 * Parameters:
 *   course_id : the course ID to search for
 */
static int find_course_index(int course_id)
{
    for (int i = 0; i < num_courses; i++)
        if (courses[i].id == course_id) return i;
    return -1;
}

/*
 * is_already_enrolled – checks whether a student is already enrolled
 * in a given course. Must be called while holding the course mutex.
 * Parameters:
 *   student_id : the student to check
 *   cidx       : the course array index
 * Returns:
 *   1 if already enrolled, 0 otherwise
 */
static int is_already_enrolled(int student_id, int cidx)
{
    for (int i = 0; i < courses[cidx].enrolled_count; i++) {
        if (courses[cidx].enrolled_ids[i] == student_id)
            return 1;
    }
    return 0;
}

/*
 * attempt_register – tries to register a student for one course.
 * This function contains the CRITICAL SECTION: it acquires the
 * per-course mutex, checks for duplicate enrollment, checks seat
 * availability, and updates the count atomically before releasing.
 *
 * Deadlock Prevention (Module 5):
 *   Each student requests one course at a time, so at most one
 *   course mutex is held by any thread at any moment – making
 *   circular wait impossible.
 *
 * Parameters:
 *   student   : pointer to the student attempting registration
 *   course_id : the course the student wants to join
 *   reason    : output buffer describing the result
 * Returns:
 *   1 on success, 0 on failure, -1 on duplicate
 */
static int attempt_register(Student *student, int course_id, char *reason)
{
    int cidx = find_course_index(course_id);
    if (cidx < 0) {
        snprintf(reason, 64, "Invalid Course ID");
        return 0;
    }

    /* ── CRITICAL SECTION BEGIN ── */
    pthread_mutex_lock(&courses[cidx].lock);

    /* Check duplicate enrollment first */
    if (is_already_enrolled(student->id, cidx)) {
        pthread_mutex_unlock(&courses[cidx].lock);
        snprintf(reason, 64, "Already Enrolled");
        return -1;
    }

    int result = 0;
    if (courses[cidx].available > 0) {
        courses[cidx].available--;
        courses[cidx].enrolled_ids[courses[cidx].enrolled_count] = student->id;
        courses[cidx].enrolled_count++;
        result = 1;
        snprintf(reason, 64, "Success");
    } else {
        snprintf(reason, 64, "No Seats Available");
    }

    pthread_mutex_unlock(&courses[cidx].lock);
    /* ── CRITICAL SECTION END ── */

    return result;
}

/* ─────────────────────────────────────────────
 * Module 4 – Priority Gate (with Aging)
 * ───────────────────────────────────────────── */

/*
 * priority_gate_enter – controls access to registration based on
 * student priority. High-priority students pass immediately.
 * Low-priority students wait while high-priority students are active,
 * unless their aging counter reaches AGING_THRESHOLD (starvation
 * prevention).
 *
 * Parameters:
 *   student : pointer to the student entering the gate
 */
static void priority_gate_enter(Student *student)
{
    pthread_mutex_lock(&priority_mutex);

    if (student->priority == PRIORITY_HIGH) {
        /* High-priority: increment active count and proceed */
        high_priority_active++;
        pthread_mutex_unlock(&priority_mutex);
        return;
    }

    /* Low-priority: wait while high-priority students are active,
     * unless aging threshold reached (starvation prevention) */
    while (high_priority_active > 0 && student->age < AGING_THRESHOLD) {
        student->age++;

        /* Timed wait: 50ms timeout prevents indefinite blocking */
        struct timespec timeout;
        clock_gettime(CLOCK_REALTIME, &timeout);
        timeout.tv_nsec += 50000000;  /* 50 ms */
        if (timeout.tv_nsec >= 1000000000) {
            timeout.tv_sec++;
            timeout.tv_nsec -= 1000000000;
        }
        pthread_cond_timedwait(&priority_cond, &priority_mutex, &timeout);
    }

    pthread_mutex_unlock(&priority_mutex);
}

/*
 * priority_gate_exit – called after registration completes.
 * If a high-priority student exits and no more are active,
 * broadcasts to wake waiting low-priority students.
 *
 * Parameters:
 *   student : pointer to the student exiting the gate
 */
static void priority_gate_exit(Student *student)
{
    if (student->priority == PRIORITY_HIGH) {
        pthread_mutex_lock(&priority_mutex);
        high_priority_active--;
        if (high_priority_active == 0) {
            /* No more high-priority students active: wake all waiters */
            pthread_cond_broadcast(&priority_cond);
        }
        pthread_mutex_unlock(&priority_mutex);
    }
    /* Low-priority students don't need to signal anything */
}

/* ─────────────────────────────────────────────
 * Module 2 – Thread Function
 * ───────────────────────────────────────────── */

/*
 * student_thread – the entry point executed by each student thread.
 * Steps:
 *   1. Waits at the barrier (synchronised start)
 *   2. For each requested course:
 *      a. Enters priority gate
 *      b. Acquires semaphore (concurrency throttle)
 *      c. Attempts registration (mutex-protected critical section)
 *      d. Releases semaphore
 *      e. Exits priority gate
 *      f. Logs result
 *   3. Returns NULL (thread terminates cleanly)
 *
 * Parameters:
 *   arg : pointer to a ThreadArg struct
 * Returns:
 *   NULL (pthread convention)
 */
static void *student_thread(void *arg)
{
    ThreadArg *targ    = (ThreadArg *)arg;
    Student   *student = targ->student;
    unsigned int seed  = (unsigned int)(student->id ^ (int)time(NULL));

    const char *priority_label = (student->priority == PRIORITY_HIGH)
                                    ? "HIGH" : "LOW ";

    /* Wait until all threads are ready for synchronised start */
    pthread_barrier_wait(&start_barrier);

    /* Attempt registration for each requested course */
    for (int r = 0; r < student->num_requests; r++) {
        int  cid   = student->course_ids[r];
        int  cidx  = find_course_index(cid);
        const char *cname = (cidx >= 0) ? courses[cidx].name : "UNKNOWN";
        char reason[64] = {0};

        /* Module 4: Enter priority gate */
        priority_gate_enter(student);

        /* Module 3: Acquire semaphore (concurrency throttle) */
        sem_wait(&registration_semaphore);

        /* Attempt the registration */
        int ok = attempt_register(student, cid, reason);

        /* Release semaphore */
        sem_post(&registration_semaphore);

        /* Exit priority gate */
        priority_gate_exit(student);

        /* Log the result */
        if (ok == 1) {
            log_event("S%d | %-30s | Priority: %s | REGISTERED  | %s",
                      student->id, cname, priority_label, reason);
            targ->success_count++;
        } else if (ok == -1) {
            log_event("S%d | %-30s | Priority: %s | SKIPPED     | %s",
                      student->id, cname, priority_label, reason);
            targ->fail_count++;
        } else {
            log_event("S%d | %-30s | Priority: %s | FAILED      | %s",
                      student->id, cname, priority_label, reason);
            targ->fail_count++;
        }

        /* Small random delay to simulate real-world timing */
        usleep((rand_r(&seed) % 50) * 1000);
    }

    return NULL;
}

/* ─────────────────────────────────────────────
 * Module 6 – Final Summary Output
 * ───────────────────────────────────────────── */

/*
 * print_summary – prints (and logs) the final seat allocation for
 * every course and the overall registration statistics.
 */
static void print_summary(void)
{
    char sep[72];
    memset(sep, '=', 70);
    sep[70] = '\0';

    log_event("%s", sep);
    log_event("                 FINAL COURSE SEAT ALLOCATION");
    log_event("%s", sep);
    log_event("%-6s  %-30s  %6s  %8s  %9s",
              "ID", "Course Name", "Total", "Enrolled", "Remaining");
    log_event("%-6s  %-30s  %6s  %8s  %9s",
              "------", "------------------------------",
              "------", "--------", "---------");

    for (int i = 0; i < num_courses; i++) {
        log_event("CS%-4d  %-30s  %6d  %8d  %9d",
                  courses[i].id,
                  courses[i].name,
                  courses[i].total_seats,
                  courses[i].enrolled_count,
                  courses[i].available);
    }

    log_event("%s", sep);
    log_event("                    SUMMARY STATISTICS");
    log_event("%s", sep);
    log_event("  Total Students          : %d", num_students);
    log_event("  High-Priority Students  : %d",
              (num_students * 33) / 100 < 3 ? 3 : (num_students * 33) / 100);
    log_event("  Successful Registrations: %d", total_success);
    log_event("  Failed Registrations    : %d", total_fail);
    log_event("  Elapsed Time            : %.1f ms", get_elapsed_ms());
    log_event("%s", sep);

    /* Verify correctness: no negative seat counts */
    int errors = 0;
    for (int i = 0; i < num_courses; i++) {
        if (courses[i].available < 0) {
            log_event("** ERROR: CS%d has negative seats (%d) – race condition!",
                      courses[i].id, courses[i].available);
            errors++;
        }
        if (courses[i].enrolled_count + courses[i].available
                != courses[i].total_seats) {
            log_event("** ERROR: CS%d seat count mismatch – data inconsistency!",
                      courses[i].id);
            errors++;
        }
    }
    if (errors == 0)
        log_event("** CORRECTNESS CHECK PASSED: No race conditions detected.");
}

/* ─────────────────────────────────────────────
 * Module 5 – Deadlock Prevention (Design)
 * ─────────────────────────────────────────────
 * Strategy: Each student thread acquires at most ONE course mutex
 * at a time (one course per attempt_register call). Because no
 * thread ever holds two course locks simultaneously, the circular-
 * wait condition required for deadlock can never occur.
 *
 * Additionally, locks are always acquired in the same order:
 *   1. priority_mutex  (enter/exit priority gate)
 *   2. course mutex    (inside attempt_register)
 *   3. stats_lock      (post-join statistics aggregation)
 *   4. log_lock        (logging)
 * No thread reverses this ordering, so no cycle can form.
 * ───────────────────────────────────────────── */

/*
 * print_usage – prints command-line usage information.
 */
static void print_usage(const char *prog)
{
    printf("Usage: %s [OPTIONS]\n", prog);
    printf("  --students N     Set number of student threads (50-200)\n");
    printf("  --stress         Stress test with 200 students\n");
    printf("  --help           Show this message\n");
}

/* ─────────────────────────────────────────────
 * main – entry point
 * ───────────────────────────────────────────── */

/*
 * main – initialises data, spawns student threads, waits for
 * completion, aggregates statistics, and prints the final summary.
 * Supports optional command-line arguments for configuration.
 */
int main(int argc, char *argv[])
{
    int student_count = 60;  /* default */

    /* Parse command-line arguments (Module: Configurable Input – Bonus) */
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--students") == 0 && i + 1 < argc) {
            student_count = atoi(argv[++i]);
            if (student_count < 10)  student_count = 10;
            if (student_count > 200) student_count = 200;
        } else if (strcmp(argv[i], "--stress") == 0) {
            student_count = 200;
        } else if (strcmp(argv[i], "--help") == 0) {
            print_usage(argv[0]);
            return 0;
        }
    }

    /* Record program start time */
    clock_gettime(CLOCK_MONOTONIC, &program_start_time);

    /* Open log file */
    log_fp = fopen(LOG_FILE, "w");
    if (!log_fp)
        fprintf(stderr, "Warning: could not open log file %s\n", LOG_FILE);

    log_event("======================================================================");
    log_event("         UNIVERSITY COURSE REGISTRATION SYSTEM");
    log_event("         CL-2006 Operating Systems Lab | Final Project");
    log_event("         Muhammad Ahmad (23F-3089)");
    log_event("======================================================================");
    log_event("Configuration: %d students | 8 courses", student_count);

    /* Module 1: Initialise data structures */
    init_courses();
    init_students(student_count, 33);  /* 33% high-priority */

    /* Log course details */
    log_event("--- Courses ---");
    for (int i = 0; i < num_courses; i++) {
        log_event("  CS%d: %-30s  [%d seats]",
                  courses[i].id, courses[i].name, courses[i].total_seats);
    }

    /* Initialise synchronisation primitives */
    pthread_barrier_init(&start_barrier, NULL, num_students + 1);
    sem_init(&registration_semaphore, 0, MAX_CONCURRENT_REGISTRATIONS);

    log_event("Spawning %d student threads...", num_students);

    /* Module 2: Create one thread per student */
    pthread_t threads[MAX_STUDENTS];
    ThreadArg args[MAX_STUDENTS];

    for (int i = 0; i < num_students; i++) {
        args[i].student       = &students[i];
        args[i].success_count = 0;
        args[i].fail_count    = 0;

        if (pthread_create(&threads[i], NULL, student_thread, &args[i]) != 0) {
            fprintf(stderr, "Error: failed to create thread for S%d\n",
                    students[i].id);
            exit(EXIT_FAILURE);
        }
    }

    /* Release all threads simultaneously */
    pthread_barrier_wait(&start_barrier);
    log_event("All %d threads released – registration in progress...",
              num_students);

    /* Module 2: Join all threads (ensure clean termination) */
    for (int i = 0; i < num_students; i++) {
        pthread_join(threads[i], NULL);

        /* Accumulate global statistics (after join – no lock needed) */
        total_success += args[i].success_count;
        total_fail    += args[i].fail_count;
    }

    log_event("All threads terminated cleanly.");

    /* Print final summary */
    print_summary();

    /* Cleanup all synchronisation primitives */
    pthread_barrier_destroy(&start_barrier);
    sem_destroy(&registration_semaphore);
    pthread_mutex_destroy(&stats_lock);
    pthread_mutex_destroy(&log_lock);
    pthread_mutex_destroy(&priority_mutex);
    pthread_cond_destroy(&priority_cond);
    for (int i = 0; i < num_courses; i++)
        pthread_mutex_destroy(&courses[i].lock);

    if (log_fp) fclose(log_fp);

    printf("\nLog saved to: %s\n", LOG_FILE);
    return 0;
}
