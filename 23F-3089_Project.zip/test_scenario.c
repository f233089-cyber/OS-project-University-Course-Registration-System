/*
 * ============================================================
 * test_scenario.c – Mandatory Demo Scenario (Section 13)
 * CL-2006 – Operating Systems Lab | Final Project
 * ============================================================
 * Group Members:
 *   Muhammad Ahmad  (23F-3089)
 *
 * Description:
 *   Implements the EXACT scenario from Section 13 of the project
 *   specification:
 *     • 3 courses: CS101 (2 seats), CS102 (1 seat), CS103 (3 seats)
 *     • 10 student threads created concurrently
 *     • At least 3 students marked as high-priority (final-year)
 *   All threads start simultaneously via a pthread_barrier.
 *   Output is timestamped and includes Student ID, Course ID,
 *   Priority level, and Result.
 *
 * OS Concepts Demonstrated:
 *   - POSIX Threads (pthread_create / pthread_join)
 *   - Mutex Locks (per-course mutual exclusion)
 *   - POSIX Semaphores (concurrency throttle)
 *   - Condition Variables (priority gate with aging)
 *   - Barriers (synchronised start)
 *   - Deadlock Prevention (single resource acquisition)
 *   - Starvation Avoidance (aging mechanism)
 *
 * Compile:  gcc -Wall -Wextra -o test_scenario test_scenario.c -lpthread
 * Run:      ./test_scenario
 * ============================================================
 */

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>
#include <stdarg.h>

/* ── Configuration ──────────────────────────── */
#define DEMO_COURSES   3
#define DEMO_STUDENTS  10
#define HIGH_PRIO      1
#define LOW_PRIO       0
#define AGING_THRESHOLD 3

/* Maximum concurrent registrations (demonstrates semaphore usage) */
#define MAX_CONCURRENT 3

/* ─────────────────────────────────────────────
 * Module 1 – Data Structures
 * ───────────────────────────────────────────── */

/*
 * DemoCourse – represents a single course in the demo scenario.
 * Fields:
 *   id          : unique course identifier
 *   name        : course name string
 *   total_seats : maximum capacity
 *   available   : current remaining seats (shared mutable state)
 *   enrolled    : count of enrolled students
 *   enrolled_ids: array tracking which students are enrolled
 *   lock        : per-course mutex protecting seat data
 */
typedef struct {
    int             id;
    char            name[16];
    int             total_seats;
    int             available;
    int             enrolled;
    int             enrolled_ids[DEMO_STUDENTS];
    pthread_mutex_t lock;
} DemoCourse;

/*
 * DemoStudent – represents one student in the demo.
 * Fields:
 *   id       : unique student identifier
 *   priority : HIGH_PRIO (final-year) or LOW_PRIO (regular)
 *   course_id: target course for this registration attempt
 *   age      : aging counter for starvation prevention
 */
typedef struct {
    int id;
    int priority;
    int course_id;
    int age;
} DemoStudent;

/*
 * DemoArg – passed to each student thread as argument.
 * Fields:
 *   student : pointer to the student record
 *   courses : pointer to the shared course array
 *   result  : 1=success, 0=fail (output)
 */
typedef struct {
    DemoStudent *student;
    DemoCourse  *courses;
    int          result;
} DemoArg;

/* ── Global Synchronisation Primitives ──────── */
static int              demo_success = 0;
static int              demo_fail    = 0;
static pthread_mutex_t  log_mutex    = PTHREAD_MUTEX_INITIALIZER;
static pthread_barrier_t barrier;

/* Module 3: Semaphore – limits concurrent registrations */
static sem_t            reg_semaphore;

/* Module 4: Priority gate – condition variable + mutex */
static pthread_mutex_t  prio_mutex   = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t   prio_cond    = PTHREAD_COND_INITIALIZER;
static int              high_prio_active = 0;

/* Program start time for relative timestamps */
static struct timespec  start_time;

/* ─────────────────────────────────────────────
 * Module 6 – Logging Helpers
 * ───────────────────────────────────────────── */

/*
 * ts – writes a HH:MM:SS.mmm timestamp into buf.
 * Parameters:
 *   buf : destination buffer
 *   sz  : size of buffer
 */
static void ts(char *buf, size_t sz)
{
    struct timespec t;
    struct tm       m;
    clock_gettime(CLOCK_REALTIME, &t);
    localtime_r(&t.tv_sec, &m);
    snprintf(buf, sz, "%02d:%02d:%02d.%03d",
             m.tm_hour, m.tm_min, m.tm_sec, (int)(t.tv_nsec / 1000000));
}

/*
 * elapsed_ms – returns milliseconds since program start.
 */
static double elapsed_ms(void)
{
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    return (now.tv_sec  - start_time.tv_sec)  * 1000.0
         + (now.tv_nsec - start_time.tv_nsec) / 1.0e6;
}

/*
 * log_line – thread-safe timestamped print to stdout.
 * Parameters:
 *   fmt : printf-style format string
 *   ... : variadic arguments
 */
static void log_line(const char *fmt, ...)
{
    char buf[512], tbuf[32];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    ts(tbuf, sizeof(tbuf));
    pthread_mutex_lock(&log_mutex);
    printf("[%s] %s\n", tbuf, buf);
    pthread_mutex_unlock(&log_mutex);
}

/* ─────────────────────────────────────────────
 * Module 3 – Synchronisation Utilities
 * ───────────────────────────────────────────── */

/*
 * find_demo_course – returns index of course matching id, else -1.
 * Parameters:
 *   courses : array of DemoCourse
 *   id      : course ID to search for
 */
static int find_demo_course(DemoCourse *courses, int id)
{
    for (int i = 0; i < DEMO_COURSES; i++)
        if (courses[i].id == id) return i;
    return -1;
}

/*
 * is_already_enrolled – checks if a student is already enrolled.
 * Must be called while holding the course mutex.
 * Parameters:
 *   course     : pointer to the course
 *   student_id : student ID to check
 * Returns:
 *   1 if already enrolled, 0 otherwise
 */
static int is_already_enrolled(DemoCourse *course, int student_id)
{
    for (int i = 0; i < course->enrolled; i++) {
        if (course->enrolled_ids[i] == student_id)
            return 1;
    }
    return 0;
}

/* ─────────────────────────────────────────────
 * Module 4 – Priority Gate with Aging
 * ───────────────────────────────────────────── */

/*
 * prio_gate_enter – high-priority students pass immediately.
 * Low-priority students wait while high-priority students are active,
 * unless their aging counter reaches AGING_THRESHOLD.
 * This prevents starvation of low-priority students.
 *
 * Parameters:
 *   student : pointer to the student entering the gate
 */
static void prio_gate_enter(DemoStudent *student)
{
    pthread_mutex_lock(&prio_mutex);

    if (student->priority == HIGH_PRIO) {
        high_prio_active++;
        pthread_mutex_unlock(&prio_mutex);
        return;
    }

    /* Low-priority: wait with aging-based starvation prevention */
    while (high_prio_active > 0 && student->age < AGING_THRESHOLD) {
        student->age++;
        struct timespec timeout;
        clock_gettime(CLOCK_REALTIME, &timeout);
        timeout.tv_nsec += 30000000;  /* 30 ms */
        if (timeout.tv_nsec >= 1000000000) {
            timeout.tv_sec++;
            timeout.tv_nsec -= 1000000000;
        }
        pthread_cond_timedwait(&prio_cond, &prio_mutex, &timeout);
    }

    pthread_mutex_unlock(&prio_mutex);
}

/*
 * prio_gate_exit – called after registration completes.
 * High-priority students decrement the active count and broadcast
 * to wake waiting low-priority students when none remain.
 *
 * Parameters:
 *   student : pointer to the student exiting the gate
 */
static void prio_gate_exit(DemoStudent *student)
{
    if (student->priority == HIGH_PRIO) {
        pthread_mutex_lock(&prio_mutex);
        high_prio_active--;
        if (high_prio_active == 0)
            pthread_cond_broadcast(&prio_cond);
        pthread_mutex_unlock(&prio_mutex);
    }
}

/* ─────────────────────────────────────────────
 * Module 2 – Thread Function
 * ───────────────────────────────────────────── */

/*
 * demo_student_thread – entry point for each student thread in the
 * mandatory demo scenario.
 * Steps:
 *   1. Wait at barrier (all threads start together)
 *   2. Enter priority gate
 *   3. Acquire semaphore (concurrency throttle)
 *   4. Lock course mutex (critical section)
 *   5. Check duplicate enrollment and seat availability
 *   6. Unlock course mutex
 *   7. Release semaphore
 *   8. Exit priority gate
 *   9. Log result with timestamp
 *
 * Parameters:
 *   arg : pointer to DemoArg struct
 * Returns:
 *   NULL (pthread convention)
 */
static void *demo_student_thread(void *arg)
{
    DemoArg     *a   = (DemoArg *)arg;
    DemoStudent *stu = a->student;
    DemoCourse  *crs = a->courses;

    const char *plabel = (stu->priority == HIGH_PRIO) ? "HIGH" : "LOW ";

    /* Synchronise: wait until all threads are ready */
    pthread_barrier_wait(&barrier);

    /* Module 4: Enter priority gate */
    prio_gate_enter(stu);

    /* Module 3: Acquire semaphore (limits concurrency) */
    sem_wait(&reg_semaphore);

    int cidx = find_demo_course(crs, stu->course_id);
    if (cidx < 0) {
        sem_post(&reg_semaphore);
        prio_gate_exit(stu);
        log_line("S%d | UNKNOWN | Priority: %s | FAILED – Bad Course ID",
                 stu->id, plabel);
        a->result = 0;
        return NULL;
    }

    /* ── CRITICAL SECTION BEGIN ── */
    pthread_mutex_lock(&crs[cidx].lock);

    int ok = 0;
    const char *reason = "No Seats Available";

    /* Check duplicate enrollment */
    if (is_already_enrolled(&crs[cidx], stu->id)) {
        reason = "Already Enrolled";
    } else if (crs[cidx].available > 0) {
        /* Atomically check and update seat count */
        crs[cidx].available--;
        crs[cidx].enrolled_ids[crs[cidx].enrolled] = stu->id;
        crs[cidx].enrolled++;
        ok = 1;
        reason = "Success";
    }

    pthread_mutex_unlock(&crs[cidx].lock);
    /* ── CRITICAL SECTION END ── */

    /* Release semaphore */
    sem_post(&reg_semaphore);

    /* Exit priority gate */
    prio_gate_exit(stu);

    a->result = ok;

    /* Log with required format: Student ID, Course ID, Priority, Result */
    if (ok) {
        log_line("S%d | CS%d | Priority: %s | SUCCESS         | %s",
                 stu->id, stu->course_id, plabel, reason);
    } else {
        log_line("S%d | CS%d | Priority: %s | FAILED          | %s",
                 stu->id, stu->course_id, plabel, reason);
    }

    return NULL;
}

/* ─────────────────────────────────────────────
 * Module 5 – Deadlock Prevention (Design)
 * ─────────────────────────────────────────────
 * Strategy:
 *   1. Each student requests exactly ONE course per thread, so only
 *      one course mutex is ever held by a thread. Circular wait is
 *      impossible.
 *   2. Lock acquisition order is always:
 *        prio_mutex → semaphore → course mutex → log_mutex
 *      No thread reverses this ordering.
 * ───────────────────────────────────────────── */

/* ─────────────────────────────────────────────
 * Module 6 – Final Summary & main
 * ───────────────────────────────────────────── */

/*
 * main – sets up the mandatory demo scenario, spawns 10 student
 * threads, waits for completion, and prints the final summary.
 */
int main(void)
{
    clock_gettime(CLOCK_MONOTONIC, &start_time);

    /* ── Course setup (exactly as specified in Section 13) ── */
    DemoCourse courses[DEMO_COURSES];
    memset(courses, 0, sizeof(courses));

    courses[0] = (DemoCourse){101, "CS101", 2, 2, 0, {0}, PTHREAD_MUTEX_INITIALIZER};
    courses[1] = (DemoCourse){102, "CS102", 1, 1, 0, {0}, PTHREAD_MUTEX_INITIALIZER};
    courses[2] = (DemoCourse){103, "CS103", 3, 3, 0, {0}, PTHREAD_MUTEX_INITIALIZER};

    for (int i = 0; i < DEMO_COURSES; i++)
        pthread_mutex_init(&courses[i].lock, NULL);

    /* ── Student setup (Section 13 spec) ──
     * Students 0,1,2 = HIGH priority (final-year)
     * Students 3–9   = LOW priority
     * Course assignments create contention on all courses */
    DemoStudent students[DEMO_STUDENTS] = {
        {2001, HIGH_PRIO, 101, 0},   /* High-priority → CS101 */
        {2002, HIGH_PRIO, 101, 0},   /* High-priority → CS101 */
        {2003, HIGH_PRIO, 102, 0},   /* High-priority → CS102 */
        {2004, LOW_PRIO,  101, 0},   /* Low-priority  → CS101 (contention) */
        {2005, LOW_PRIO,  102, 0},   /* Low-priority  → CS102 (contention) */
        {2006, LOW_PRIO,  103, 0},   /* Low-priority  → CS103 */
        {2007, LOW_PRIO,  103, 0},   /* Low-priority  → CS103 */
        {2008, LOW_PRIO,  103, 0},   /* Low-priority  → CS103 */
        {2009, LOW_PRIO,  103, 0},   /* Low-priority  → CS103 (contention) */
        {2010, LOW_PRIO,  101, 0},   /* Low-priority  → CS101 (contention) */
    };

    DemoArg   args[DEMO_STUDENTS];
    pthread_t threads[DEMO_STUDENTS];

    /* Initialise synchronisation primitives */
    pthread_barrier_init(&barrier, NULL, DEMO_STUDENTS + 1);
    sem_init(&reg_semaphore, 0, MAX_CONCURRENT);

    /* Print scenario header */
    printf("\n");
    printf("=============================================================\n");
    printf("  MANDATORY TEST SCENARIO – Section 13\n");
    printf("  CL-2006 Operating Systems Lab | Final Project\n");
    printf("  Muhammad Ahmad (23F-3089)\n");
    printf("=============================================================\n");
    printf("  Courses:\n");
    printf("    CS101: %d seats\n", courses[0].total_seats);
    printf("    CS102: %d seats\n", courses[1].total_seats);
    printf("    CS103: %d seats\n", courses[2].total_seats);
    printf("  Students: %d threads | 3 high-priority (final-year)\n",
           DEMO_STUDENTS);
    printf("  Synchronisation: Mutex + Semaphore + Condition Variable\n");
    printf("  Priority: Gate with aging (threshold=%d)\n", AGING_THRESHOLD);
    printf("=============================================================\n\n");

    /* Module 2: Spawn student threads */
    for (int i = 0; i < DEMO_STUDENTS; i++) {
        args[i].student = &students[i];
        args[i].courses = courses;
        args[i].result  = 0;

        if (pthread_create(&threads[i], NULL, demo_student_thread, &args[i]) != 0) {
            fprintf(stderr, "Error: failed to create thread for S%d\n",
                    students[i].id);
            exit(EXIT_FAILURE);
        }
    }

    /* Release all threads simultaneously */
    pthread_barrier_wait(&barrier);

    /* Module 2: Join all threads (ensure clean termination) */
    for (int i = 0; i < DEMO_STUDENTS; i++) {
        pthread_join(threads[i], NULL);
        if (args[i].result) demo_success++;
        else                demo_fail++;
    }

    /* ── Final Summary ── */
    printf("\n=============================================================\n");
    printf("  FINAL SEAT ALLOCATION\n");
    printf("=============================================================\n");
    printf("%-8s  %-6s  %8s  %8s  %9s\n",
           "Course", "Name", "Total", "Enrolled", "Remaining");
    printf("%-8s  %-6s  %8s  %8s  %9s\n",
           "--------", "------", "--------", "--------", "---------");
    for (int i = 0; i < DEMO_COURSES; i++) {
        printf("CS%-6d  %-6s  %8d  %8d  %9d\n",
               courses[i].id, courses[i].name,
               courses[i].total_seats,
               courses[i].enrolled,
               courses[i].available);
    }

    /* Enrolled student lists */
    printf("\n  Enrolled Students per Course:\n");
    for (int i = 0; i < DEMO_COURSES; i++) {
        printf("    CS%d: ", courses[i].id);
        if (courses[i].enrolled == 0) {
            printf("(none)");
        } else {
            for (int j = 0; j < courses[i].enrolled; j++) {
                printf("S%d", courses[i].enrolled_ids[j]);
                if (j < courses[i].enrolled - 1) printf(", ");
            }
        }
        printf("\n");
    }

    printf("\n=============================================================\n");
    printf("  SUMMARY STATISTICS\n");
    printf("=============================================================\n");
    printf("  Total Students             : %d\n", DEMO_STUDENTS);
    printf("  High-Priority Students     : 3\n");
    printf("  Low-Priority Students      : 7\n");
    printf("  Successful Registrations   : %d\n", demo_success);
    printf("  Failed Registrations       : %d\n", demo_fail);
    printf("  Total Seat Capacity        : %d\n",
           courses[0].total_seats + courses[1].total_seats + courses[2].total_seats);
    printf("  Elapsed Time               : %.1f ms\n", elapsed_ms());

    /* Correctness verification */
    printf("\n  Correctness Checks:\n");
    int pass = 1;
    for (int i = 0; i < DEMO_COURSES; i++) {
        if (courses[i].available < 0) {
            printf("    [FAIL] CS%d: negative seats (%d)\n",
                   courses[i].id, courses[i].available);
            pass = 0;
        }
        if (courses[i].enrolled + courses[i].available != courses[i].total_seats) {
            printf("    [FAIL] CS%d: seat count mismatch\n", courses[i].id);
            pass = 0;
        }
    }
    if (demo_success + demo_fail != DEMO_STUDENTS) {
        printf("    [FAIL] Total results (%d) != total students (%d)\n",
               demo_success + demo_fail, DEMO_STUDENTS);
        pass = 0;
    }
    if (pass) {
        printf("    [PASS] No race conditions detected\n");
        printf("    [PASS] No negative seat counts\n");
        printf("    [PASS] All threads terminated cleanly\n");
        printf("    [PASS] Seat count consistency verified\n");
    }

    printf("=============================================================\n\n");

    /* Cleanup synchronisation primitives */
    pthread_barrier_destroy(&barrier);
    sem_destroy(&reg_semaphore);
    pthread_mutex_destroy(&prio_mutex);
    pthread_cond_destroy(&prio_cond);
    for (int i = 0; i < DEMO_COURSES; i++)
        pthread_mutex_destroy(&courses[i].lock);

    return 0;
}
